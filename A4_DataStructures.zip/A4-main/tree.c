#include "tree.h"

void attachNode( struct memsys *memsys, int *node_ptr, void *src, unsigned int width ){
    int data = memmalloc(memsys,width);
    setval(memsys,src,width,data);
    int nodeAddr = memmalloc(memsys,sizeof(struct  Node));
    struct Node node;
    node.data=data;
    node.lt=MEMNULL;
    node.gte=MEMNULL;
    setval(memsys,&node,sizeof(struct Node),nodeAddr);
    *node_ptr=nodeAddr;
}

void attachChild( struct memsys *memsys, int *node_ptr, void *src, unsigned int width, int direction ){
    struct Node node;
    getval(memsys,&node,sizeof(struct Node),*node_ptr);

    if(direction<0){
        attachNode(memsys,&node.lt,src,width);
    }else{
        attachNode(memsys,&node.gte,src,width);
    }
    setval(memsys,&node,sizeof(struct Node),*node_ptr);

}

int comparNode( struct memsys *memsys, int *node_ptr, int (*compar)(const void *, const void *), void *target, unsigned int width ){
    struct Node node;
    getval(memsys,&node,sizeof(struct Node),*node_ptr);
    void * nodeData = malloc(width);
    getval(memsys,nodeData,width,node.data);
    int comp = compar(target,nodeData);
    free(nodeData);
    return comp;
}

int next( struct memsys *memsys, int *node_ptr, int direction ){
    struct Node node;
    getval(memsys,&node,sizeof(struct Node),*node_ptr);
    return (direction<0)?node.lt:node.gte;
}

void readNode( struct memsys *memsys, int *node_ptr, void *dest, unsigned int width ){
    if(*node_ptr==MEMNULL){
        fprintf(stderr,"Empty node readNode");
        exit(-1);
    }
    struct Node node;
    getval(memsys,&node,sizeof(struct Node),*node_ptr);
    getval(memsys,dest,width,node.data);

}

void detachNode( struct memsys *memsys, int *node_ptr ){
    if(*node_ptr==MEMNULL){
        fprintf(stderr,"Empty node detachNode");
        exit(-1);
    }
    struct Node node;
    getval(memsys,&node,sizeof(struct Node),*node_ptr);
    memfree(memsys,node.data);
    memfree(memsys,*node_ptr);
    *node_ptr=MEMNULL;
}

void freeNodes( struct memsys *memsys, int *node_ptr ){
    if(*node_ptr==MEMNULL)
        return;

    struct Node node;
    getval(memsys,&node,sizeof(struct Node),*node_ptr);

    if(node.lt==MEMNULL && node.gte==MEMNULL){
        detachNode(memsys,node_ptr);
        return;
    }

    freeNodes(memsys,&node.lt);
    freeNodes(memsys,&node.gte);
    detachNode(memsys,node_ptr);

}

struct Tree *newTree( struct memsys *memsys, unsigned int width ){
    struct Tree *tree = malloc(sizeof(struct Tree));
    tree->root=MEMNULL;
    tree->width=width;
    return tree;
}

void freeTree( struct memsys *memsys, struct Tree *tree ){
    freeNodes(memsys,&(tree->root));
    free(tree);
}

void addItem( struct memsys *memsys, struct Tree *tree, int (*compar)(const void *, const void *), void *src ){
    if(tree->root==MEMNULL){

        attachNode(memsys,&(tree->root),src,tree->width);
        return;
    }

    int current = tree->root;
    int previous = current;
    while (current!=MEMNULL){
        previous = current;
        current = next(memsys,&current,comparNode(memsys,&current,compar,src,tree->width));
    }
    attachChild(memsys,&previous,src,tree->width,comparNode(memsys,&previous,compar,src,tree->width));
}

int searchItem( struct memsys *memsys, struct Tree *tree, int (*compar)(const void *, const void *), void *target ){
    int current = tree->root;
    while (current!=MEMNULL){
        if(comparNode(memsys,&current,compar,target,tree->width)==0){
            readNode(memsys,&current,target,tree->width);
            return 1;
        }
        current = next(memsys,&current,comparNode(memsys,&current,compar,target,tree->width));
    }
    return 0;
}
